CREATE TABLE habitacion (
    id SERIAL PRIMARY KEY,
    numero VARCHAR(50) NOT NULL UNIQUE,
    tipo VARCHAR(100) NOT NULL, 
    descripcion TEXT, 
    foto_url VARCHAR(255),
    estado VARCHAR(50) NOT NULL, 
    precio DOUBLE PRECISION DEFAULT 00.0 
);